package jersey.data;


public class Client {
  
	String name;
}
